# comenta.me V4 — Formspree connected

Static HTML + Vanilla JavaScript (AJAX), deployed via GitHub → Vercel.

## Deploy
1. Upload `index.html` and `gracias.html` to the root of your GitHub repository, replacing the current versions.
2. Commit to your Vercel production branch.
3. Wait for Vercel to deploy.
4. Submit one test email and one test phone number.
5. Confirm both appear in your Formspree dashboard (form `maeqagje`).

## Behavior
- One required field accepts a valid email or a phone number (10–15 digits; optional international prefix).
- Sends `contact`, `contact_type`, `source` and the applicable `email` or `phone` field to `https://formspree.io/f/maeqagje` via JSON fetch.
- After HTTP success, redirects to `./gracias.html`.
- On invalid values or failed requests, stays on the landing page with a visible error.
- Prevents duplicate submissions while awaiting response.

## Launch note
Add a privacy notice appropriate for Mexican users before public lead collection.
Demo feedback/dashboard features are local simulation only.
